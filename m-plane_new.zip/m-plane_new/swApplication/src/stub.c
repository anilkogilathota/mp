/**
 */
#define _GNU_SOURCE

#include "mplane.h"

int main()
{
    int rc = SR_ERR_OK, ans = 0, ans1 = 0;
    char xpath[500];
    char datastore[100];
    char value[100];
    char *notif_nodes[] = {"fault-id", "fault-source", "affected-objects[0]/name", "fault-severity", "is-cleared", "fault-text", "event-time"};
    char *notif_xpath = "/o-ran-fm:alarm-notif";
    char *notif_values[100] = {'\0'};
    notif_values[1] = "O-RU";
    notif_values[2] = "O-RU";
    notif_values[4] = "true";
    
    printf("Select operation:\n 1. Get\n 2. Set\n 3. Alarm Notification\n 4. Exit\n");
    scanf("%d", &ans);
    
    create_mplane_session();

    while(1)
    {
        switch(ans)
        {
            case 1:
                printf("--Get operation--\n");
                printf("Enter xpath:");
                scanf("%s", xpath);
                printf("Enter datastore[startup/running/operational/candidatie]:");
                scanf("%s", datastore);
                get_items(xpath, datastore);
                break;
            case 2:
                printf("--Set operation--\n");
                printf("Enter xpath:");
                scanf("%s", xpath);
                printf("Enter value:");
                scanf("%s", value);
                set_item(xpath, value);
                break;
            case 3:
                printf("Alarm notification operation:\n  1. Unit temperature is high\n  2. Unit dangerously overheating\n  3. Temperature too low\n");
                scanf("%d", &ans1);

                switch(ans1)
                {
                    case 1:
                        printf("--Unit temperature is high--\n");
                        notif_values[0] = "1";
                        notif_values[3] = "MAJOR";
                        notif_values[5] = "Unit temperature is high";
                        notif_values[6] = "2021-05-07T08:01:50Z";
                        send_notification(notif_xpath, 7, notif_nodes, notif_values);
                        break;
                    case 2:
                        printf("--Unit dangerously heating--\n");
                        notif_values[0] = "2";
                        notif_values[3] = "CRITICAL";
                        notif_values[5] = "Unit dangerously heating";
                        notif_values[6] = "2021-05-07T08:01:50Z";
                        send_notification(notif_xpath, 7, notif_nodes, notif_values);
                        break;
                    case 3:
                        printf("--Temperature is low--\n");
                        notif_values[0] = "4";
                        notif_values[3] = "MINOR";
                        notif_values[5] = "Temperature is low";
                        notif_values[6] = "2021-05-07T08:01:50Z";
                        send_notification(notif_xpath, 7, notif_nodes, notif_values);
                        break;
                    default:
                        printf("Wrong Input\n");
                }
                break;
            case 4:
                printf("Exiting\n");
                delete_mplane_session();
                return EXIT_SUCCESS;
            default:
                printf("Wrong Input\n");
        }
        printf("\n\nSelect operation:\n 1. Get\n 2. Set\n 3. Alarm Notification\n 4. Exit\n");
        scanf("%d", &ans);
    }
    
    delete_mplane_session();

    return rc ? EXIT_FAILURE : EXIT_SUCCESS;
}
