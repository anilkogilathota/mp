#include "sw_mplane.h"

void init_callback()
{
    mplane_subscribe(FILE_UPLOAD,sw_file_upload);
    mplane_subscribe(FILE_DOWNLOAD,sw_file_download);
    mplane_subscribe(SOFTWARE_DOWNLOAD,sw_software_download);
    mplane_subscribe(SOFTWARE_INSTALL,sw_software_install);
    mplane_subscribe(SOFTWARE_ACTIVATE,sw_software_activate);
}

int supervision_notif_send_notification(void *input)
{
    create_mplane_session();
    printf("\n\n custom fun called \n\n");
    send_notification("/o-ran-supervision:supervision-notification",0,NULL,NULL);
    delete_mplane_session();

    return 0;
}

int sw_file_upload(void *input)
{
    char cmd[100];
    const char *local_logical_file_path, *remote_file_path;
    local_logical_file_path = mplane_get_value("local-logical-file-path",input);
    remote_file_path = mplane_get_value("remote-file-path",input);
    printf("local-logical-file-path value is %s\n",local_logical_file_path);
    printf("remote-file-path is %s\n",remote_file_path);
    printf("File will be uploaded from %s to %s\n",local_logical_file_path,remote_file_path);
    snprintf(cmd,100,"cp %s %s",local_logical_file_path, remote_file_path);
    system(cmd);
    printf("========== File upload successfull. ==========\n");
    char *notif_nodes[4] = {"local-logical-file-path","remote-file-path","status","reject-reason"};
    char *notif_values[4] = {'\0'};
    notif_values[0] = local_logical_file_path;
    notif_values[1] = remote_file_path;
    notif_values[2] = "SUCCESS";
    create_mplane_session();
    if(notif_values[2])
    {
        send_notification("/o-ran-file-management:file-upload-notification",3,notif_nodes,notif_values);
    }
    else
    {
        notif_values[2] = "FAILURE";
        notif_values[3] = "FILE UPLOAD FAILED";
        send_notification("/o-ran-file-management:file-upload-notification",4,notif_nodes,notif_values);
    }
    delete_mplane_session();
    return 0;
}

int sw_file_download(void *input)
{
    char cmd[100];
    const char *local_logical_file_path, *remote_file_path;
    local_logical_file_path = mplane_get_value("local-logical-file-path",input);
    remote_file_path = mplane_get_value("remote-file-path",input);
    printf("local-logical-file-path value is %s\n",local_logical_file_path);
    printf("remote-file-path is %s\n",remote_file_path);
    printf("File will be uploaded from %s to %s\n",local_logical_file_path,remote_file_path);
    const char *password;
    password = mplane_get_value("password",input);
    printf("password is %s\n",password);
    snprintf(cmd,100,"cp %s %s",local_logical_file_path, remote_file_path);
    system(cmd);
    printf("========== File Download successfull. ==========\n");
    char *notif_nodes[4] = {"local-logical-file-path","remote-file-path","status","reject-reason"};
    char *notif_values[4] = {'\0'};
    notif_values[0] = local_logical_file_path;
    notif_values[1] = remote_file_path;
    notif_values[2] = "SUCCESS";
    create_mplane_session();
    if(notif_values[2])
    {
        send_notification("/o-ran-file-management:file-download-event",3,notif_nodes,notif_values);
    }
    else
    {
        notif_values[2] = "FAILURE";
        notif_values[3] = "FILE Download FAILED";
        send_notification("/o-ran-file-management:file-download-event",4,notif_nodes,notif_values);
    }
    delete_mplane_session();
    return 0;
}

int sw_software_download(void *input)
{
    const char *remote_file_path;
    remote_file_path = mplane_get_value("remote-file-path",input);
    printf("remote-file-path is %s\n",remote_file_path);
    printf("Software will be downloaded from %s\n",remote_file_path);
    const char *password;
    password = mplane_get_value("password",input);
    printf("password is %s\n",password);
    printf("========== Software Download successfull. ==========\n");
    char *notif_nodes[3] = {"file-name","status","error-message"};
    char *notif_values[3] = {'\0'};
    notif_values[0] = "file.zip";
    notif_values[1] = "COMPLETED";
    create_mplane_session();
    if(notif_values[1])
    {
        send_notification("/o-ran-software-management:download-event",2,notif_nodes,notif_values);
    }
    else
    {
        notif_values[1] = "FILE_NOT_FOUND";
        notif_values[2] = "FILE NOT FOUND";
        send_notification("/o-ran-software-management:download-event",3,notif_nodes,notif_values);
    }
    delete_mplane_session();
    return 0;
}

int sw_software_install(void *input)
{
    /* Software install */
    char *notif_nodes[3] = {"slot-name","status","error-message"};
    char *notif_values[3] = {'\0'};
    notif_values[0] = mplane_get_value("slot-name",input);
    notif_values[1] = "COMPLETED";
    create_mplane_session();
    if(notif_values[1]) 
    {
        send_notification("/o-ran-software-management:install-event",2,notif_nodes,notif_values);
    }
    else
    {
        notif_values[1] = "FILE_ERROR";
        notif_values[2] = "operation on the file resulted in in error, disk failure, not enough disk space, incompatible file format" ;
        send_notification("/o-ran-software-management:install-event",3,notif_nodes,notif_values);
    }
    delete_mplane_session();
    return 0;
}

int sw_software_activate(void *input)
{
    /* Software activate */
    char *notif_nodes[4] = {"slot-name","status","return-code","error-message"};
    char *notif_values[4] = {'\0'};
    notif_values[0] = mplane_get_value("slot-name",input);
    notif_values[1] = "COMPLETED";
    notif_values[2] = "1";
    create_mplane_session();
    if(notif_values[1])
    {
        send_notification("/o-ran-software-management:activation-event",3,notif_nodes,notif_values);
    }
    else
    {
        notif_values[1] = "FILE_ERROR";
        notif_values[3] = "operation on the file resulted in in error, disk failure, not enough disk space, incompatible file format" ;
        send_notification("/o-ran-software-management:activation-event",4,notif_nodes,notif_values);
    }
    delete_mplane_session();
    return 0;
}
