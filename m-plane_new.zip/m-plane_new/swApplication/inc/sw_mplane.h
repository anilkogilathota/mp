#include "mplane.h"

void init_callback();
int supervision_notif_send_notification(void *input);
