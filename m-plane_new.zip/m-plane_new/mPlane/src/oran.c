
#include "oran.h"

const char* mplane_get_password(const char *UNUSED(file_name), const struct lyd_node *key1, const char* username)
{
    const struct lyd_node *key;
    const char *value = NULL;
    key = lyd_child(key1);
    while(key){
        if(!strcmp(mplane_get_leaf("name",key),username))
        {
            return mplane_get_leaf("password",key);
        }

        key = key->next;
    }
    return value;
}

int
np2srv_rpc_file_upload_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *UNUSED(op_path), const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data))
{
    struct lyd_node *config = NULL;
    struct np2_user_sess *user_sess = NULL;
    int rc = SR_ERR_OK;
    printf("========== File upload request recieved. ==========\n");
    if (NP_IGNORE_RPC(session, event)) {
        /* ignore in this case */
        return SR_ERR_OK;
    }
    /* get the user session */
    if ((rc = np_get_user_sess(session, NULL, &user_sess))) {
        goto cleanup;
    }
    
    /* add output */
    
    if(!(mplane_get_leaf("local-logical-file-path",input) && mplane_get_leaf("remote-file-path",input))){
        /*status FAILURE*/
        if (lyd_new_term(output,NULL,"status", "FAILURE", LYD_ANYDATA_STRING, NULL))
        {
            goto cleanup;
        }
        if (lyd_new_term(output, NULL, "reject-reason", "local-logical-file-path or remote-file-path value is null", LYD_ANYDATA_STRING, NULL))
        {
            goto cleanup;
        }
        goto cleanup;
    }

    if(lyd_new_term(output,NULL,"status","SUCCESS",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
    }
    mplane_rpc[FILE_UPLOAD](input);

    goto cleanup;

    /* success */

cleanup:
    if (user_sess) {
        /* discard any changes that possibly failed to be applied */
        sr_discard_changes(user_sess->sess);
    }
    lyd_free_siblings(config);
    np_release_user_sess(user_sess);
    return rc;
}

int
np2srv_rpc_file_download_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *UNUSED(op_path), const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data))
{
    struct lyd_node *config = NULL;
    struct np2_user_sess *user_sess = NULL;
    int rc = SR_ERR_OK;
    printf("========== File download request recieved. ==========\n");
    if (NP_IGNORE_RPC(session, event)) {
        /* ignore in this case */
        return SR_ERR_OK;
    }
    /* get the user session */
    if ((rc = np_get_user_sess(session, NULL, &user_sess))) {
        goto cleanup;
    }
    
    /* add output */

    if(!(mplane_get_leaf("local-logical-file-path",input) && mplane_get_leaf("remote-file-path",input))){
        /*status FAILURE*/
        if (lyd_new_term(output,NULL,"status", "FAILURE", LYD_ANYDATA_STRING, NULL))
        {
            goto cleanup;
        }
        if (lyd_new_term(output, NULL, "reject-reason", "local-logical-file-path or remote-file-path value is null", LYD_ANYDATA_STRING, NULL))
        {
            goto cleanup;
        }
        goto cleanup;
    }

    if(lyd_new_term(output,NULL,"status","SUCCESS",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
    }
    mplane_rpc[FILE_DOWNLOAD](input);

    goto cleanup;

    /* success */

cleanup:
    if (user_sess) {
        /* discard any changes that possibly failed to be applied */
        sr_discard_changes(user_sess->sess);
    }
    lyd_free_siblings(config);
    np_release_user_sess(user_sess);
    return rc;
}

int
np2srv_rpc_retrieve_file_list_cb(sr_session_ctx_t *UNUSED(session), uint32_t UNUSED(sub_id), const char *UNUSED(op_path), const struct lyd_node *input, sr_event_t UNUSED(event), uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data))
{
          struct lyd_node *data_get = NULL;
          struct np2_filter filter = {0};
          int rc = SR_ERR_OK;
          struct np2_user_sess *user_sess = NULL;
          const char *val, *val1, *search_item;
          struct lyd_node *key;
          char cmd[100];
          //printf("[[%s][%x]]\n",input->schema->name,input->schema->nodetype);
          printf("****File retrieve-list request has been accepted.\n");
          for(key=lyd_child(input);key;)
          {
            val=lyd_get_value(key);
            //printf("[[%s][%s][%x]]\n",val,key->schema->name,key->schema->nodetype);
            if(strcmp(key->schema->name,"logical-path")==0)
            val1=val;
            if(strcmp(key->schema->name,"file-name-filter")==0)
            search_item=val;
            if(key->schema->nodetype == LYS_LEAF)
            {
              key=key->next;
            }
            else key=lyd_child(key);
          }
          snprintf(cmd,100,"find %s -name %s",val1,search_item);
          FILE *fptr = popen(cmd,"r");
          char buffer[200]="", *current=buffer;
          int bytes, chunk=20; //, size=sizeof(buffer)/sizeof(char);
          if (fptr == NULL)
          {
            //printf("File [%s] NOT found in the logical path [%s] : .\n",search_item,val1);
            current="File NOT found.";
          }// Read contents from file
          else if(fptr)
          {
            do {
              bytes=fread(current,sizeof(char),chunk,fptr);
              current+=bytes;
                } while (bytes==chunk);

          }
          pclose(fptr);
          *current='\0';
          // print the buffer
          //printf("%s",buffer);
          if(!(mplane_get_leaf("logical-path",input) && mplane_get_leaf("file-name-filter",input))){
              /*status FAILURE*/
              if (lyd_new_term(output,NULL,"status", "FAILURE", LYD_ANYDATA_STRING, NULL))
              {
                  goto cleanup;
              }
              if (lyd_new_term(output, NULL, "reject-reason", "local-logical-file-path or remote-file-path value is null", LYD_ANYDATA_STRING, NULL))
              {
                  goto cleanup;
              }
              goto cleanup;
         }
         else{
          if(lyd_new_term(output,NULL,"status","SUCCESS",LYD_ANYDATA_STRING,NULL)){
              goto cleanup;
            }
          if(lyd_new_term(output,NULL,"file-list",buffer,LYD_ANYDATA_STRING,NULL)){
                  goto cleanup;
            }
          }

          cleanup:
              op_filter_erase(&filter);
              lyd_free_siblings(data_get);
              np_release_user_sess(user_sess);
              return rc;
              //return 0;*/

}

int
np2srv_rpc_software_download_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *UNUSED(op_path), const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data))
{
    struct lyd_node *config = NULL;
    struct np2_user_sess *user_sess = NULL;
    int rc = SR_ERR_OK;
    printf("========== Software Download request recieved. ==========\n");
    if (NP_IGNORE_RPC(session, event)) {
        /* ignore in this case */
        return SR_ERR_OK;
    }
    /* get the user session */
    if ((rc = np_get_user_sess(session, NULL, &user_sess))) {
        goto cleanup;
    }
    
    /* add output */
    if(!(mplane_get_leaf("remote-file-path",input))){
        /*status FAILURE*/
        if (lyd_new_term(output,NULL,"status", "FAILURE", LYD_ANYDATA_STRING, NULL))
        {
            goto cleanup;
        }
        if (lyd_new_term(output, NULL, "reject-reason", "local-logical-file-path or remote-file-path value is null", LYD_ANYDATA_STRING, NULL))
        {
            goto cleanup;
        }
        goto cleanup;
    }
    if(lyd_new_term(output,NULL,"status","STARTED",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
    }
    mplane_rpc[SOFTWARE_DOWNLOAD](input);

    goto cleanup;

    /* success */

cleanup:
    if (user_sess) {
        /* discard any changes that possibly failed to be applied */
        sr_discard_changes(user_sess->sess);
    }
    lyd_free_siblings(config);
    np_release_user_sess(user_sess);
    return rc;
}

int
np2srv_rpc_software_install_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *UNUSED(op_path), const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data))
{
    struct lyd_node *config = NULL;
    struct np2_user_sess *user_sess = NULL;
    int rc = SR_ERR_OK;
    printf("========== Software Install request recieved. ==========\n");
    if (NP_IGNORE_RPC(session, event)) {
        /* ignore in this case */
        return SR_ERR_OK;
    }
    /* get the user session */
    if ((rc = np_get_user_sess(session, NULL, &user_sess))) {
        goto cleanup;
    }
    
    /* add output */
    if(lyd_new_term(output,NULL,"status","STARTED",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
    }
    mplane_rpc[SOFTWARE_INSTALL](input);

    goto cleanup;

    /* success */

cleanup:
    if (user_sess) {
        /* discard any changes that possibly failed to be applied */
        sr_discard_changes(user_sess->sess);
    }
    lyd_free_siblings(config);
    np_release_user_sess(user_sess);
    return rc;
}

int
np2srv_rpc_software_activate_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *UNUSED(op_path), const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data))
{
    struct lyd_node *config = NULL;
    struct np2_user_sess *user_sess = NULL;
    int rc = SR_ERR_OK;
    printf("========== Software activate request recieved. ==========\n");
    if (NP_IGNORE_RPC(session, event)) {
        /* ignore in this case */
        return SR_ERR_OK;
    }
    /* get the user session */
    if ((rc = np_get_user_sess(session, NULL, &user_sess))) {
        goto cleanup;
    }
    
    /* add output */
    if(lyd_new_term(output,NULL,"status","STARTED",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
    }
    mplane_rpc[SOFTWARE_ACTIVATE](input);

    goto cleanup;

    /* success */

cleanup:
    if (user_sess) {
        /* discard any changes that possibly failed to be applied */
        sr_discard_changes(user_sess->sess);
    }
    lyd_free_siblings(config);
    np_release_user_sess(user_sess);
    return rc;
}

int
np2srv_rpc_chg_password_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *UNUSED(op_path), const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data))
{
    printf("\n****successfull******\n");
    struct lyd_node *config = NULL;
    struct np2_user_sess *user_sess = NULL;
    struct nc_session *nc_sess = NULL;

    sr_conn_ctx_t *connection = NULL;
    sr_session_ctx_t *sr_session = NULL;

    int rc = SR_ERR_OK;
    const char* user = NULL, *currentPassword = NULL, *newPassword = NULL, *newPasswordConfirm = NULL;
    const char *pass = NULL;
    currentPassword = mplane_get_leaf("currentPassword",input);
    newPassword = mplane_get_leaf("newPassword",input);
    newPasswordConfirm = mplane_get_leaf("newPasswordConfirm",input);
    
    printf("========== Change password request recieved. ==========\n");
    
    if (NP_IGNORE_RPC(session, event)) {
        /* ignore in this case */
        return SR_ERR_OK;
    }

    /* get the user session and nc_session */
    if ((rc = np_get_user_sess(session, &nc_sess, &user_sess))) {
        goto cleanup;
    }

    user = nc_session_get_username(nc_sess);    
    char xpath_pass[100] = "/o-ran-usermgmt:users/user[name='";
    const char* username = "STLII";
    strcat(xpath_pass,username);
    strcat(xpath_pass,"']/password");

    sr_session_switch_ds(session, SR_DS_RUNNING);
    sr_get_data(session, xpath_pass, 0, 0, 0, &config);
    pass =  mplane_get_password("password", config, user);

    /*comparing rpc password with user's password in usermgmt*/
    if(strcmp(pass, currentPassword))
    {
        printf("[ERR]: CurrentPassword in rpc doesn't match with user currentPassword\n");
        rc = !SR_ERR_OK;
    }

    /*comparing if newPassword and newPasswordConfirm are same */
    if(strcmp(newPassword, newPasswordConfirm))
    {
        printf("[ERR]: newPassword and newPasswordConfirm in RPC are different\n");
        rc = !SR_ERR_OK;
    }

    if(rc == SR_ERR_OK)
    {
        /* connect to sysrepo */
        rc = sr_connect(0, &connection);
        if (rc != SR_ERR_OK) {
            sr_disconnect(connection);
            printf("\n[ERR]: SR: connection to sysrepo failed.\n");
            goto cleanup;
        }

        ctx = sr_get_context(connection);

        /* start session */
        rc = sr_session_start(connection, SR_DS_RUNNING, &sr_session);

        if (rc != SR_ERR_OK) {
            printf("\n[ERR]: SR: Couldn't start sysrepo session.\n\n");
            sr_disconnect(connection);
            goto cleanup;
        }

        /*updating the user password*/
        sr_set_item_str(sr_session, xpath_pass, newPassword, NULL, 0);

         if (rc != SR_ERR_OK) {
            return rc;
        }

        /* apply the change */
        rc = sr_apply_changes(sr_session, 0);
        if (rc != SR_ERR_OK) {
            return rc;
        }
    
    }
    /* add output */
    if(rc == SR_ERR_OK)
    {
        printf("========== Change password request Successful. ==========\n");
        if(lyd_new_term(output,NULL,"status","Successful",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
        }    
    }
    else
    {
        printf("========== Change password request Successful. ==========\n");
        if(lyd_new_term(output,NULL,"status","Failed",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
        }   
    }
    

    cleanup:
    if (user_sess) {
        /* discard any changes that possibly failed to be applied */
        sr_discard_changes(user_sess->sess);
    }
    lyd_free_siblings(config);
    rc = sr_session_stop(sr_session);
    sr_disconnect(connection);

    np_release_user_sess(user_sess);

    return rc;
}

int interactive_auth_clb(const struct nc_session *session, ssh_message msg, void *UNUSED(user_data))
{
    int auth_ret = 1;
    const char *pass_hash = NULL;
    struct lyd_node *config = NULL;
    sr_conn_ctx_t *connection = NULL;
    sr_session_ctx_t *sr_session = NULL;
    int rc = SR_ERR_OK;
    const char* val = NULL; 

    printf("\n\n************starting interactive_auth_clb function called************ \n");
    
    if (!ssh_message_auth_kbdint_is_response(msg)) {
            const char *prompts[] = {"Password: "};
            char echo[] = {0};
            
            ssh_message_auth_interactive_request(msg, "Interactive SSH Authentication", "Type your password:", 1, prompts, echo);
            auth_ret = -1;
        } 
        else {
            if (ssh_userauth_kbdint_getnanswers(nc_session_get_ssh_session(session)) != 1) {// failed session
                ssh_message_reply_default(msg);
                goto cleanup;
            }
            
            /*creating xpath to check the usermgmt database*/
            char xpath[100] = "/o-ran-usermgmt:users/user[name='";
            const char* username = NULL; 

            /*getting nc_username of session*/
            username = nc_session_get_username(session);

            strcat(xpath,username);
            strcat(xpath,"']");
            
            /* connect to sysrepo */
            rc = sr_connect(0, &connection);
            if (rc != SR_ERR_OK) {
                sr_disconnect(connection);
                printf("\n[ERR]: SR: connection to sysrepo failed.\n");
                goto cleanup;
            }

            /* start session */
            rc = sr_session_start(connection, SR_DS_RUNNING, &sr_session);

            if (rc != SR_ERR_OK) {
                printf("\n[ERR]: SR: Couldn't start sysrepo session.\n\n");
                sr_disconnect(connection);
                goto cleanup;
            }

            /*get config node for user-mgmt config*/
            sr_get_data(sr_session, xpath, 0, 0, 0, &config);

            if(!config)
            {
                printf("\n\n[ERR]: SR: Couldn't access the sysrepo o-ran-usermgmt database\n");
            }

            val = mplane_get_leaf("name", config);

            if(!val){
                printf("\n[ERR]: SR: User \"%s\" not found in user-management database\n", username);
                goto cleanup;
            }

            pass_hash = mplane_get_password("password", config, username);
            if(!pass_hash){
                printf("\n[ERR]: SR: Couldn't find password for User \"%s\" in user-management database\n", username);
                goto cleanup;
            }
            
            if(!strcmp(pass_hash,ssh_userauth_kbdint_getanswer(nc_session_get_ssh_session(session), 0))){
                auth_ret = 0;
                goto cleanup;
            }
            

        }
    cleanup:
    //printf("\n\n************interactive_auth_clb function called************ \n");
    lyd_free_siblings(config);

    rc = sr_session_stop(sr_session);
    
    sr_disconnect(connection);
    
    return auth_ret;
}

int passwd_auth_clb(const struct nc_session *session, const char *password, void *UNUSED(user_data))
{
    int auth_ret = 1;
    const char *pass_hash = NULL;
    struct lyd_node *config = NULL;
    sr_conn_ctx_t *connection = NULL;
    sr_session_ctx_t *sr_session = NULL;
    int rc = SR_ERR_OK;
    const char* val = NULL; 

    printf("\n\n************passwd auth called\n\n");
    char xpath[100] = "/o-ran-usermgmt:users/user[name='";
    const char* username = NULL;
    username = nc_session_get_username(session);
    strcat(xpath,username);
    strcat(xpath,"']");
            
    /* connect to sysrepo */
    rc = sr_connect(0, &connection);
    if (rc != SR_ERR_OK) {
        sr_disconnect(connection);
        printf("\ns[ERR]: SR: connection to sysrepo failed.\n");
        goto cleanup;
    }


    /* start session */
    rc = sr_session_start(connection, SR_DS_RUNNING, &sr_session);

    if (rc != SR_ERR_OK) {
        printf("\n*[ERR]: SR: session didn't start.\n");
        sr_disconnect(connection);
        goto cleanup;
    }

    /* Getting o-ran-usermgmt config*/
    sr_get_data(sr_session, xpath, 0, 0, 0, &config);

    if(!config)
    {
        printf("\n\n[ERR]: SR: Couldn't access the sysrepo o-ran-usermgmt database\n");
        goto cleanup;
    }
    
    val = mplane_get_leaf("name", config);

    if(!val){
        printf("\n[ERR]: SR: User \"%s\" not found in user-management database\n", username);
        goto cleanup;
    }

    pass_hash = mplane_get_password("password", config, username);
    if(!pass_hash){
        printf("\n[ERR]: SR: Couldn't find password for User: \"%s\" in user-management database\n", username);
        goto cleanup;
    }
    
    if(!strcmp(pass_hash,password)){
        auth_ret = 0;
        goto cleanup;
    }

    cleanup:
    lyd_free_siblings(config);
    rc = sr_session_stop(sr_session);
    sr_disconnect(connection);

    printf("\n\nauth pass called\n");
    
    return auth_ret;    
}

int init()
{
#define SR_RPC_SUBSCR(xpath, cb) \
    rc = sr_rpc_subscribe_tree(np2srv.sr_sess, xpath, cb, NULL, 0, SR_SUBSCR_CTX_REUSE, &np2srv.sr_rpc_sub); \
    if (rc != SR_ERR_OK) { \
        printf("Subscribing for \"%s\" RPC failed (%s).", xpath, sr_strerror(rc)); \
        return -1; \
    }

    /*subscribe to file-management RPCs */
    SR_RPC_SUBSCR("/o-ran-file-management:file-upload", np2srv_rpc_file_upload_cb);
    SR_RPC_SUBSCR("/o-ran-file-management:file-download",np2srv_rpc_file_download_cb);
    SR_RPC_SUBSCR("/o-ran-file-management:retrieve-file-list",np2srv_rpc_retrieve_file_list_cb);

    /*subscribe to software-management RPCs */
    SR_RPC_SUBSCR("/o-ran-software-management:software-download",np2srv_rpc_software_download_cb);
    SR_RPC_SUBSCR("/o-ran-software-management:software-install",np2srv_rpc_software_install_cb);
    SR_RPC_SUBSCR("/o-ran-software-management:software-activate",np2srv_rpc_software_activate_cb);

    /* subscribe to user-management */
    SR_RPC_SUBSCR("/o-ran-usermgmt:chg-password",np2srv_rpc_chg_password_cb);

    /* subscribe to supervision-watchdog-reset */
    SR_RPC_SUBSCR("/o-ran-supervision:supervision-watchdog-reset",np2srv_rpc_supervision_sub_cb);

    /* subscribe to troubleshooting logs */
    SR_RPC_SUBSCR("/o-ran-troubleshooting:start-troubleshooting-logs",np2srv_rpc_start_troubleshooting_logs_cb);
    SR_RPC_SUBSCR("/o-ran-troubleshooting:stop-troubleshooting-logs",np2srv_rpc_stop_troubleshooting_logs_cb);

    /* User-mgmt */
    nc_server_ssh_set_interactive_auth_clb(interactive_auth_clb,NULL, NULL);
    nc_server_ssh_set_passwd_auth_clb(passwd_auth_clb, NULL, NULL);

   return SR_ERR_OK;
}

int
np2srv_rpc_start_troubleshooting_logs_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *UNUSED(op_path), const struct lyd_node *UNUSED(input), sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data))
{
    struct lyd_node *config = NULL;
    struct np2_user_sess *user_sess = NULL;
    int rc = SR_ERR_OK;
    int flag = 0;
    printf("========== Start troubleshooting request recieved. ==========\n");
    if (NP_IGNORE_RPC(session, event)) {
        /* ignore in this case */
        return SR_ERR_OK;
    }
    /* get the user session */
    if ((rc = np_get_user_sess(session, NULL, &user_sess))) {
        goto cleanup;
    }
    printf("\n before calling troubleshooting logs\n");
    /*start creating troubleshoot log files*/
    /*stub function called*/
    flag = 0;
    //const char *path = troubleshoot_logs();
    //printf("%s\n", path );

    /* add output */
    if(!flag)
    {
        if(lyd_new_term(output,NULL,"status","SUCCESS",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
        }
    }
    else
    {
        if(lyd_new_term(output,NULL,"status","FAILURE",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
        }
        if(lyd_new_term(output,NULL,"reject-reason","Couldn't create log files",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
        }   
    }

    goto cleanup;

    /* success */

cleanup:
    if (user_sess) {
        /* discard any changes that possibly failed to be applied */
        sr_discard_changes(user_sess->sess);
    }
    lyd_free_siblings(config);
    np_release_user_sess(user_sess);
    return rc;
}

int
np2srv_rpc_stop_troubleshooting_logs_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *UNUSED(op_path), const struct lyd_node *UNUSED(input), sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data))
{
    struct lyd_node *config = NULL;
    struct np2_user_sess *user_sess = NULL;
    int rc = SR_ERR_OK;
    int flag = 0;
    printf("========== Stop troubleshooting request recieved. ==========\n");
    if (NP_IGNORE_RPC(session, event)) {
        /* ignore in this case */
        return SR_ERR_OK;
    }
    /* get the user session */
    if ((rc = np_get_user_sess(session, NULL, &user_sess))) {
        goto cleanup;
    }

    /*stop creating troubleshoot log files*/
    /*stub function called*/
    flag = 0;


    /* add output */
    if(!flag)
    {
        if(lyd_new_term(output,NULL,"status","SUCCESS",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
        }
    }
    else
    {
        if(lyd_new_term(output,NULL,"status","FAILURE",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
        }
        if(lyd_new_term(output,NULL,"reject-reason","Couldn't create log files",LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
        }   
    }

    goto cleanup;

    /* success */

cleanup:
    if (user_sess) {
        /* discard any changes that possibly failed to be applied */
        sr_discard_changes(user_sess->sess);
    }
    lyd_free_siblings(config);
    np_release_user_sess(user_sess);
    return rc;
}

int
np2srv_rpc_supervision_sub_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *UNUSED(op_path), const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data))
{

    struct np2_user_sess *user_sess = NULL;
    int rc = SR_ERR_OK;
    time_t rawtime;
    struct tm * timeinfo;
    char out[100];
    char guard_timer[5];
    char supervision_interval[5];
    int supervision_interval_int,guard_timer_int;
    int minute = 0, seconds=0;
    int ret = 0;
    memset(guard_timer,0,5);
    memset(supervision_interval,0,5);
    printf("========== Supervisoin rpc recieved. ==========\n");
    if (NP_IGNORE_RPC(session, event)) {
        /* ignore in this case */
        return SR_ERR_OK;
    }
    /* get the user session */
    if ((rc = np_get_user_sess(session, NULL, &user_sess))) {
        goto cleanup;
    }
    time(&rawtime);
    timeinfo = localtime(&rawtime);

    printf("%s:%d, leaf name:%s\n\r",__func__,__LINE__,input->schema->name);
    strcpy(supervision_interval,mplane_get_value("supervision-notification-interval",(void*)input));
    if (supervision_interval == NULL)
    {
        supervision_interval_int = 60; //Setting it to default.
    }
    else
    {
        supervision_interval_int = atoi(supervision_interval);
    }
    printf("%s:%d, supervision_interval:%s, converted to int:%d\n\r",__func__,__LINE__,supervision_interval,supervision_interval_int);
    
    strcpy(guard_timer,mplane_get_value("guard-timer-overhead",(void*)input));
    if (guard_timer == NULL)
    {
        guard_timer_int = 10; //Setting it to default.
    }
    else
    { 
        guard_timer_int = atoi(guard_timer);
    }
    printf("%s:%d, guard_timer:%s, converted to int:%d\n\r",__func__,__LINE__,guard_timer,guard_timer_int);
    
    sprintf(out, "%.4d-%.2d-%.2dT%.2d:%.2d:%.2d+05:30",
            timeinfo->tm_year+1900,timeinfo->tm_mon+1,timeinfo->tm_mday,timeinfo->tm_hour, timeinfo->tm_min, timeinfo->tm_sec);
    printf("%s:%d, current system date-and-time:%s\n\r",__func__,__LINE__,out);

    //To calculate the value for next supervision interval
    minute = supervision_interval_int / 60;
    seconds = supervision_interval_int % 60;

    minute += guard_timer_int / 60;
    seconds += guard_timer_int % 60;

    printf("%s:%d, minute:%d, seconds:%d\n\r",__func__,__LINE__,minute,seconds);
    rawtime += seconds;
    timeinfo = localtime(&rawtime);
    
    sprintf(out, "%.4d-%.2d-%.2dT%.2d:%.2d:%.2d+05:30",
            timeinfo->tm_year+1900,timeinfo->tm_mon+1,timeinfo->tm_mday,timeinfo->tm_hour, timeinfo->tm_min, timeinfo->tm_sec);
    printf("%s:%d, next system date-and-time:%s\n\r",__func__,__LINE__,out);
    /* add output */
    if(lyd_new_term(output,NULL,"next-update-at",out,LYD_ANYDATA_STRING,NULL)){
        goto cleanup;
    }

    //sleep(seconds);
    /* success */
    ret = supervision_notif_send_notification((void *)input);
    if(ret == 0)
        printf("%s:%d, ###########Supervision notification sent successfully#########\n\r",__func__,__LINE__);
    else
        printf("%s:%d, ###########Supervision notification not sent successfully#########\n\r",__func__,__LINE__);

cleanup:
    if (user_sess) {
        /* discard any changes that possibly failed to be applied */
        sr_discard_changes(user_sess->sess);
    }
    np_release_user_sess(user_sess);
    return rc;

}
