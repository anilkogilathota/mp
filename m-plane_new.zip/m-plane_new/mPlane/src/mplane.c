#include "mplane.h"
sr_conn_ctx_t *connection = NULL;
sr_session_ctx_t *session = NULL;
int rc = SR_ERR_OK;
const struct ly_ctx *ctx;
int(*mplane_rpc[10]) ();

const char* troubleshoot_logs()
{
    /*code to creat troubleshooting logs here*/
    const char* path = "/oran/logs/troubleshoot_logs";
    printf("\n\n*********troubleshoot_logs called*********\n");
    return path;
}

void mplane_subscribe(int opt, int(*cb_func)())
{
    switch (opt){
        case FILE_UPLOAD:
            mplane_rpc[FILE_UPLOAD] = cb_func;
            break;
        case FILE_DOWNLOAD:
            mplane_rpc[FILE_DOWNLOAD] = cb_func;
            break;
        case SOFTWARE_DOWNLOAD:
            mplane_rpc[SOFTWARE_DOWNLOAD] = cb_func;
            break;
        case SOFTWARE_INSTALL:
            mplane_rpc[SOFTWARE_INSTALL] = cb_func;
            break;
        case SOFTWARE_ACTIVATE:
            mplane_rpc[SOFTWARE_ACTIVATE] = cb_func;
            break;
        default:
            printf("ERR: Invalid args in mplane_subscribe(option, cb_function)\n");
            break;
    }
}

const char* mplane_get_value(const char * file_name, void *input)
{
    const struct lyd_node *key;
    key = lyd_child(input);
    return mplane_get_leaf(file_name,key);
}

const char* mplane_get_leaf(const char * file_name, const struct lyd_node *key1)
{
    const struct lyd_node *child, *key = NULL;
    key =  key1;
    const char *value = NULL;
    while(key){
        if((!strcmp(key->schema->name,file_name))&& key->schema->nodetype == 4){
            value = lyd_get_value(key);
            return value;
        }
        child = lyd_child(key);
        if(child){
            value = mplane_get_leaf(file_name,child);
            if(value)
                return value;
        }
        key = key->next;
    }
    return value;
}

void print_val(const sr_val_t *value)
{
    if (NULL == value) {
        return;
    }

    printf("%s ", value->xpath);

    switch (value->type) {
    case SR_CONTAINER_T:
    case SR_CONTAINER_PRESENCE_T:
        printf("(container)");
        break;
    case SR_LIST_T:
        printf("(list instance)");
        break;
    case SR_STRING_T:
        printf("= %s", value->data.string_val);
        break;
    case SR_BOOL_T:
        printf("= %s", value->data.bool_val ? "true" : "false");
        break;
    case SR_DECIMAL64_T:
        printf("= %g", value->data.decimal64_val);
        break;
    case SR_INT8_T:
        printf("= %" PRId8, value->data.int8_val);
        break;
    case SR_INT16_T:
        printf("= %" PRId16, value->data.int16_val);
        break;
    case SR_INT32_T:
        printf("= %" PRId32, value->data.int32_val);
        break;
    case SR_INT64_T:
        printf("= %" PRId64, value->data.int64_val);
        break;
    case SR_UINT8_T:
        printf("= %" PRIu8, value->data.uint8_val);
        break;
    case SR_UINT16_T:
        printf("= %" PRIu16, value->data.uint16_val);
        break;
    case SR_UINT32_T:
        printf("= %" PRIu32, value->data.uint32_val);
        break;
    case SR_UINT64_T:
        printf("= %" PRIu64, value->data.uint64_val);
        break;
    case SR_IDENTITYREF_T:
        printf("= %s", value->data.identityref_val);
        break;
    case SR_INSTANCEID_T:
        printf("= %s", value->data.instanceid_val);
        break;
    case SR_BITS_T:
        printf("= %s", value->data.bits_val);
        break;
    case SR_BINARY_T:
        printf("= %s", value->data.binary_val);
        break;
    case SR_ENUM_T:
        printf("= %s", value->data.enum_val);
        break;
    case SR_LEAF_EMPTY_T:
        printf("(empty leaf)");
        break;
    default:
        printf("(unprintable)");
        break;
    }

    switch (value->type) {
    case SR_UNKNOWN_T:
    case SR_CONTAINER_T:
    case SR_CONTAINER_PRESENCE_T:
    case SR_LIST_T:
    case SR_LEAF_EMPTY_T:
        printf("\n");
        break;
    default:
        printf("%s\n", value->dflt ? " [default]" : "");
        break;
    }
}

int create_mplane_session()
{
    printf("create mplane session started\n");

    /* turn logging on */
    sr_log_stderr(SR_LL_WRN);

    /* connect to sysrepo */
    rc = sr_connect(0, &connection);
    if (rc != SR_ERR_OK) {
        sr_disconnect(connection);
        return rc;
    }
    ctx = sr_get_context(connection);
    printf("create mplane session done\n");

    return EXIT_SUCCESS;
}

int delete_mplane_session()
{
    sr_disconnect(connection);
    printf("mplane session deleted\n");
 
    return EXIT_SUCCESS;
}

int send_notification_new(char *path, int num_of_nodes, char *node[], char *value[])
{
    struct lyd_node *notif = NULL;
    struct lyd_node *notif1 = NULL;

    /* start session */
    rc = sr_session_start(connection, SR_DS_OPERATIONAL, &session);
    if (rc != SR_ERR_OK) {
        sr_disconnect(connection);
                return rc;
    }

    /* create the notification */
    if (lyd_new_path(NULL, ctx, path, NULL, 0, &notif)) {
        printf("Creating notification \"%s\" failed.\n", path);
        return EXIT_FAILURE;
    }

    if (lyd_new_path(notif, ctx, "active-alarms", NULL, 0, &notif1)) {
        printf("Creating notification \"%s\" failed.\n", path);
        return EXIT_FAILURE;
    }
    /* add the input values */
    for(int i = 0; i < num_of_nodes; i++)
    {
        if (lyd_new_path(notif1, NULL, node[i], value[i], 0, NULL)) {
            printf("Creating value \"%s\" failed.\n", node[i]);
            return EXIT_FAILURE;
        }
    }

    rc = sr_edit_batch(session, notif, "merge");
    if (rc != SR_ERR_OK) {
        return EXIT_FAILURE;
    }
    sr_apply_changes(session,0);
    lyd_free_all(notif);
    return EXIT_SUCCESS;
}

int send_notification(char *path, int num_of_nodes, char *node[], char *value[])
{
    struct lyd_node *notif = NULL;

    /* start session */
    rc = sr_session_start(connection, SR_DS_RUNNING, &session);
    if (rc != SR_ERR_OK) {
        sr_disconnect(connection);
        return rc;
    }

    /* create the notification */
    if (lyd_new_path(NULL, ctx, path, NULL, 0, &notif)) {
        printf("Creating notification \"%s\" failed.\n", path);
        return EXIT_FAILURE;
    }

    /* add the input values */
    for(int i = 0; i < num_of_nodes; i++)
    {
        if (lyd_new_path(notif, NULL, node[i], value[i], 0, NULL)) {
            printf("Creating value \"%s\" failed.\n", node[i]);
            return EXIT_FAILURE;
        }
    }

    /* send the notification */
    rc = sr_event_notif_send_tree(session, notif, 0, 0);
    if (rc != SR_ERR_OK) {
        return EXIT_FAILURE;
    }

    lyd_free_all(notif);
    
    return EXIT_SUCCESS;
}

int get_items(char *xpath, char *datastore)
{
    sr_val_t *vals = NULL;
    size_t i, val_count = 0;
    sr_datastore_t ds = SR_DS_RUNNING;

    if (datastore != NULL) {
        if (!strcmp(datastore, "running")) {
            ds = SR_DS_RUNNING;
        } else if (!strcmp(datastore, "operational")) {
            ds = SR_DS_OPERATIONAL;
        } else if (!strcmp(datastore, "startup")) {
            ds = SR_DS_STARTUP;
        } else if (!strcmp(datastore, "candidate")) {
            ds = SR_DS_CANDIDATE;
        } else {
            printf("Invalid datastore %s\n", datastore);
            return EXIT_FAILURE;
        }
    }
    else
    {
        ds = SR_DS_RUNNING;
    }

    printf("Application will get \"%s\" from \"%s\" datastore.\n\n", xpath, datastore?datastore:"running");

    /* start session */
    rc = sr_session_start(connection, ds, &session);
    if (rc != SR_ERR_OK) {
        return rc;
    }

    /* get the values */
    rc = sr_get_items(session, xpath, 0, 0, &vals, &val_count);
    if (rc != SR_ERR_OK) {
        return rc;
    }

    /* print the values */
    for (i = 0; i < val_count; ++i) {
        print_val(&vals[i]);
    }

    sr_free_values(vals, val_count);
    
    return EXIT_SUCCESS;
}

int set_item(char *xpath, char *value)
{
    printf("Application will set \"%s\" to \"%s\".\n", xpath, value);

    /* start session */
    rc = sr_session_start(connection, SR_DS_OPERATIONAL, &session);
    if (rc != SR_ERR_OK) {
        return rc;
    }

    /* set the value */
    rc = sr_set_item_str(session, xpath, value, NULL, 0);
    if (rc != SR_ERR_OK) {
        return rc;
    }

    /* apply the change */
    rc = sr_apply_changes(session, 0);
    if (rc != SR_ERR_OK) {
        return rc;
    }

    return EXIT_SUCCESS;
}
