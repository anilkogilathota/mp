#include <inttypes.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <libyang/libyang.h>
#include <sysrepo.h>
#include "common.h"
#include "../build/config.h"
#include "mplane.h"
#include <time.h>

extern int(*mplane_rpc[10]) ();
int 
np2srv_rpc_file_upload_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *op_path, const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data));

int 
np2srv_rpc_file_download_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *op_path, const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data));

int 
np2srv_rpc_retrieve_file_list_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *op_path, const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data));

int
np2srv_rpc_software_download_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *op_path, const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data));

int
np2srv_rpc_software_install_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *op_path, const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data));

int
np2srv_rpc_software_activate_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *op_path, const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data));

int
np2srv_rpc_chg_password_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *op_path, const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data));

int 
interactive_auth_clb(const struct nc_session *session, ssh_message msg, void *user_data);

int 
passwd_auth_clb(const struct nc_session *session, const char *password, void *user_data);

int
np2srv_rpc_start_troubleshooting_logs_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *op_path, const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data));

int
np2srv_rpc_stop_troubleshooting_logs_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *op_path, const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data));

int
np2srv_rpc_supervision_sub_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const char *op_path, const struct lyd_node *input, sr_event_t event, uint32_t UNUSED(request_id), struct lyd_node *output, void *UNUSED(private_data));

int 
init();
