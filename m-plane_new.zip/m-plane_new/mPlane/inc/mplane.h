#include <inttypes.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <libyang/libyang.h>
#include "sysrepo.h"

#define FILE_UPLOAD 0 
#define FILE_DOWNLOAD 1
#define SOFTWARE_DOWNLOAD 2
#define SOFTWARE_INSTALL 3
#define SOFTWARE_ACTIVATE 4

//int(*mplane_rpc[10]) ();
//extern int(*mplane_rpc[10]) ();

extern sr_conn_ctx_t *connection;
extern sr_session_ctx_t *session;
extern int rc;
extern const struct ly_ctx *ctx;

extern int sw_file_upload(void *input);
extern int sw_file_download(void *input);
extern int sw_software_download(void *input);
extern int sw_software_install(void *input);
extern int sw_software_activate(void *input);

const char* troubleshoot_logs();

const char* mplane_get_value(const char * file_name, void *input);
const char* mplane_get_leaf(const char * file_name, const struct lyd_node *key);
const char* mplane_get_password(const char * file_name, const struct lyd_node *key, const char* username);

//void mplane_subscribe(int val, int(*myfunc)());
void print_val(const sr_val_t *value);
int create_mplane_session();
int delete_mplane_session();
int send_notification(char *path, int num_of_nodes, char *node[], char *value[]);
int get_items(char *xpath, char *datastore);
int set_item(char *xpath, char *value);
